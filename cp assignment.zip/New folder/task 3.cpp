#include<iostream>
using namespace std;
int main ()
{
  int marks;
cout << "Enter marks: ";
cin >> marks;
if (marks > 80)
{
cout << "Student has marks above 80";
}
return o;
}
