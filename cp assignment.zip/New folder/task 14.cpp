#include<iostream>
using namespace std;
int main ()
{
  float temperature;
cout << "Enter temperature: ";
cin >> temperature;
if (temperature > 30)
{
cout << "Temperature is above 30\B0C";
}
return o;
}
