#include<iostream>
using namespace std;
int main ()
{
  int price;
cout << "Enter product price:";
cin >> price;
if (price > 5000)
{
cout << "Product price is above 5000";
}
return 0;
}
