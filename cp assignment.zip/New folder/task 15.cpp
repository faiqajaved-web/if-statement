#include<iostream>
using namespace std;
int main ()
{
  int age;
cout << "Enter age: ";
cin >> age;
if (age > 60)
{
cout << "Age is above 60";
}
return 0;
}
