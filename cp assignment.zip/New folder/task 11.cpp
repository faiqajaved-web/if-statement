#include<iostream>
using namespace std;
int main ()
{
  int marks;
cout << "Enter marks:";
cin >> marks;
if (marks >= 40)
{
cout << "Student has passed.";
}
return 0;
}
