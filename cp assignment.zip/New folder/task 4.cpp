#include<iostream>
using namespace std;
int main ()
{
  int number;
cout << "Enter a number: ";
cin >> number;
if (number > 50)
{
           cout << "Number is greater than 50";
}
return 0;
}
