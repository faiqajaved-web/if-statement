#include<iostream>
using namespace sdt;
int main ()
{
  int num;
cout << "Enter a number: ";
cin >> num;
if (num % 2 == 0)
{
cout << "Number is even.";
}
return 0;
}
