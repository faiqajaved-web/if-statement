#include<iostream>
using namespace std;
int main ()
{
  int number;
cout << "Enter a number: ";
cin >> number;
if (number == 100)
{
cout << "Number is equal to 100";
}
return 0;
}
